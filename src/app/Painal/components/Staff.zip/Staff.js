'use client';
import { useState } from 'react';
import { useAuth } from './context/AuthContext';

export default function Staff() {
  const { user } = useAuth();

  return (
    <div className="container py-4">
      <div className="card shadow-sm">
        <div className="card-header bg-primary text-white">
          <h4 className="mb-0">Staff Management</h4>
        </div>
        <div className="card-body">
          <div className="alert alert-info">
            <p className="mb-0">Manage staff members for {user?.cityName || 'your city'}</p>
          </div>
          
          <div className="d-flex justify-content-between mb-3">
            <div>
              <button className="btn btn-primary me-2">
                <i className="bi bi-plus-lg"></i> Add Staff Member
              </button>
              <button className="btn btn-outline-secondary">
                <i className="bi bi-filter"></i> Filter
              </button>
            </div>
            <div className="input-group w-auto">
              <input type="text" className="form-control" placeholder="Search staff..." />
              <button className="btn btn-outline-secondary" type="button">
                <i className="bi bi-search"></i>
              </button>
            </div>
          </div>
          
          <div className="table-responsive">
            <table className="table table-hover">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Role</th>
                  <th>Contact</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td colSpan="5" className="text-center py-4">No staff members found</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
} 