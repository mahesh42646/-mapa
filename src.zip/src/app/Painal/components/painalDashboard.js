'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth } from './context/AuthContext';
import axios from 'axios';

export default function Dashboard() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [profilePhoto, setProfilePhoto] = useState('');

  useEffect(() => {
    // Initialize Bootstrap JS when component mounts
    if (typeof window !== 'undefined') {
      require('bootstrap/dist/js/bootstrap.bundle.min.js');
    }
  }, []);

  useEffect(() => {
    if (user?.avatar) {
      setProfilePhoto(`http://localhost:5004${user.avatar}`);
    }
  }, [user]);

  if (loading) return null;
  if (!user) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '60vh' }}>
        <h3>Login to access this</h3>
      </div>
    );
  }

  // Format the name to show FirstName MiddleInitial
  const formatName = (fullName) => {
    if (!fullName) return 'User';

    const nameParts = fullName.split(' ');
    if (nameParts.length === 1) return nameParts[0];

    // First name + middle initial
    return `${nameParts[0]} ${nameParts[1].charAt(0)}`;
  };

  return (
    <div className='Dashboard container d-lg-flex py-4'>
      <div className='d-lg-flex gap-3 pe-lg-3 col-lg-8'>
        <div className='p-4 w-100 rounded-3 shadow bg-lite-green'>
          <div className='w-100 d-flex'>
            <div className='col-8'>
              <div className='text-green-600' style={{ fontSize: "28px", fontWeight: "800" }}>
                Bem vindo de volta 👋
                <div className="mb-0">{formatName(user.name)}.</div>
              </div>
              <p className='pt-4 text-green-600'>Gerenciar sua cidade cultural nunca foi tão fácil!</p>
            </div>
            <div className='col-4 d-flex'>
              <img src='./images/dashboard-vector.png' alt="dashboard" className="w-100 m-auto ps-2" />
            </div>
          </div>
        </div>
      </div>
      
      <div className='py-4 px-3 rounded-3 shadow bg-gray-50 col-lg-4 d-flex flex-column'>
        <div className='w-100 d-flex'>
          <div className='p-3 rounded-circle' style={{ height: "100px", width: "100px" }}>
            <img src={profilePhoto || './images/citi-icon.png'} alt='City' className='shadow w-100 rounded-circle p-2' />
          </div>
          <div className='col-9 h-100 d-flex'>
            <div className='my-auto px-4'>
              <h5>My City</h5>
              <h2>{user.cityName || 'Loading...'}</h2>
            </div>
          </div>
        </div>
        <div className='w-100 d-flex border-top'>
          <div className='px-4 pt-3'>
            <i className="bi bi-person-fill text-primary pe-2"></i> 
            Created by: {user.createdByName || 'Admin'}
          </div>
          <div className='px-4 pt-3'>
            <i className="bi bi-check-circle text-success pe-2"></i>
            {user.cityStatus || 'Ativo'}
          </div>
        </div>
      </div>
    </div>
  );
} 