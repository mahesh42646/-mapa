'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth } from '@/app/Master/context/AuthContext';
import axios from 'axios';




export default function Dashboard() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [profilePhoto, setProfilePhoto] = useState('');
  const [cities, setCities] = useState([]);
 



  useEffect(() => {
    // Initialize Bootstrap JS when component mounts
    if (typeof window !== 'undefined') {
      require('bootstrap/dist/js/bootstrap.bundle.min.js');
    }
  }, []);

  useEffect(() => {
    if (user?.email) {
      axios.get(`https://mapadacultura.com/api/user/${user.email}`)
        .then(response => {
          if (response.data.profilePhoto) {
            setProfilePhoto(`https://mapadacultura.com/api${response.data.profilePhoto}`);
          }
        })
        .catch(error => {
          console.error('Error fetching user profile:', error);
        });

     
    }
  }, [user]);

  useEffect(() => {
    // Fetch cities data
    axios.get('https://mapadacultura.com/city-api/city')
      .then(response => {
        setCities(response.data);
      })
      .catch(error => {
        console.error('Error fetching cities:', error);
      });
  }, []);

  // Calculate city stats
  const totalCities = cities.length;
  const activeCities = cities.filter(city => city.cityStatus === 'Ativo').length;
  const inactiveCities = cities.filter(city => city.cityStatus === 'Inativo').length;

  // useEffect(() => {
  //   if (!loading && !user) { router.push('/Master/Login'); }
  // }, [user, loading, router]);
  if (loading) return null;
  if (!user) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '60vh' }}>
        <h3>Login to access this</h3>
      </div>
    );
  }

  // Format the name to show FirstName MiddleInitial
  const formatName = (fullName) => {
    if (!fullName) return 'User';

    const nameParts = fullName.split(' ');
    if (nameParts.length === 1) return nameParts[0];

    // First name + middle initial
    return `${nameParts[0]} ${nameParts[1].charAt(0)}`;
  };

  return (
    <div className='Dashboard container d-lg-flex py-4'>
      <div className='d-lg-flex gap-3 pe-lg-3  col-lg-8'>
        <div className='p-4  w-100 rounded-3 shadow bg-lite-green'>
          <div className='w-100 d-flex  '>
            <div className='col-8'>
              <div className='text-green-600' style={{ fontSize: "28px", fontWeight: "800" }}>  Bem vindo de volta 👋  <div className="mb-0">{formatName(user.name)}.</div>  </div>
              <p className='pt-4 text-green-600'>Deseja verificar os últimos projetos realizados na sua rede cultural?</p>
              {/* <button className='btn mt-2 text-white btn-lg border  px-4 rounded-3 primary-btn' onClick={() => router.push('/projects')} >Ver projetos</button> */}

            </div>
            <div className='col-4 d-flex '>
              <img src='./images/dashboard-vector.png' alt="dashboard " className=" w-100 m-auto ps-2" />
            </div>
          </div>
        </div>
        
      </div>
      <div className='py-4 px-3 rounded-3 shadow bg-gray-50 col-lg-4 d-flex flex-column'>
          <div className='w-100 d-flex'>
            <div className=' p-3 rounded-circle' style={{ height: "100px", width: "100px" }}>
              <img src='./images/citi-icon.png' alt='Cities' className='shadow w-100 rounded-circle p-2 ' />
            </div>
            <div className='col-9 h-100 d-flex '>
              <div className='my-auto px-4'>
                <h5> Cities</h5>
                <h2>{totalCities}</h2>
              </div>
            </div>
          </div>
          <div className='w-100 d-flex border-top'>
            <div className='px-4 pt-3 '>
              <i className="bi bi-graph-up-arrow text-success pe-2"></i> {activeCities} Actives
            </div>
            <div className='px-4 pt-3 '>
              <i className="bi bi-graph-down-arrow text-danger pe-2"></i>
             {inactiveCities} Inactive
            </div>
          </div>
        </div>

    </div>
  );
}
